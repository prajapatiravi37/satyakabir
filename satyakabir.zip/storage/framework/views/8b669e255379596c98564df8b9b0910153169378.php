<!DOCTYPE html>
<html>
<head>
    <title>Your New Password</title>
</head>
<body>
    <h2>Hello,</h2>
    <p>Your new password is: <strong><?php echo e($newPassword); ?></strong></p>
    <p>Please log in and change your password immediately.</p>
    <p>Thank you!</p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\2025\satyakabir\satyakabir\resources\views/emails/forgot_password.blade.php ENDPATH**/ ?>